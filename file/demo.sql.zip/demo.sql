-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2015 年 09 月 24 日 09:50
-- 服务器版本: 5.6.12-log
-- PHP 版本: 5.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `demo`
--
CREATE DATABASE IF NOT EXISTS `demo` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `demo`;

-- --------------------------------------------------------

--
-- 表的结构 `tp_brand`
--

CREATE TABLE IF NOT EXISTS `tp_brand` (
  `bId` int(4) NOT NULL AUTO_INCREMENT,
  `bName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `bLogo` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `bCont` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`bId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='品牌' AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `tp_brand`
--

INSERT INTO `tp_brand` (`bId`, `bName`, `bLogo`, `bCont`) VALUES
(1, '劲霸男装', 'Public/Uploads/brand/5603b133ec82e.png', ''),
(2, '杰克琼斯', 'Public/Uploads/brand/5603b13ddd40a.png', ''),
(3, '海澜之家', 'Public/Uploads/brand/5603b1493d090.png', ''),
(4, '韩都衣社', 'Public/Uploads/brand/5603b155d9701.png', '');

-- --------------------------------------------------------

--
-- 表的结构 `tp_classify`
--

CREATE TABLE IF NOT EXISTS `tp_classify` (
  `cId` int(4) NOT NULL AUTO_INCREMENT,
  `fId` int(4) NOT NULL,
  `cName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `cCont` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `tp_classify`
--

INSERT INTO `tp_classify` (`cId`, `fId`, `cName`, `cCont`) VALUES
(1, 0, '服装', ''),
(2, 1, '男装', ''),
(3, 2, '夹克', ''),
(4, 1, '女装', ''),
(5, 4, '连衣裙', ''),
(6, 1, '童装', ''),
(7, 4, '女士衬衣', ''),
(8, 6, '爬爬裤', '');

-- --------------------------------------------------------

--
-- 表的结构 `tp_items`
--

CREATE TABLE IF NOT EXISTS `tp_items` (
  `iId` int(4) NOT NULL AUTO_INCREMENT,
  `iCid` int(4) NOT NULL,
  `iFid` int(4) NOT NULL,
  `iBid` int(4) NOT NULL,
  `iCode` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `iName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `iImg` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `iSize` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `iColor` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `iPrice` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `iStyle` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `iDate` date NOT NULL,
  `iCont` text COLLATE utf8_unicode_ci NOT NULL,
  `iState` int(2) NOT NULL,
  PRIMARY KEY (`iId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='商品' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `tp_items`
--

INSERT INTO `tp_items` (`iId`, `iCid`, `iFid`, `iBid`, `iCode`, `iName`, `iImg`, `iSize`, `iColor`, `iPrice`, `iStyle`, `iDate`, `iCont`, `iState`) VALUES
(1, 3, 2, 0, '20150924', '2015上衣', 'Public/Uploads/item/5603b3b2c65d4.png', 'XL', '米黄', '359', '休闲', '2015-09-24', '收拾收拾所属', 0);

-- --------------------------------------------------------

--
-- 表的结构 `tp_users`
--

CREATE TABLE IF NOT EXISTS `tp_users` (
  `uId` int(4) NOT NULL AUTO_INCREMENT,
  `uName` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `uPass` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `uPic` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `tp_users`
--

INSERT INTO `tp_users` (`uId`, `uName`, `uPass`, `uPic`) VALUES
(1, 'admin', 'admin', 'Public/Uploads/users/5603ae1766ff3.png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
